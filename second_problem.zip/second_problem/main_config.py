# mysqldb 

from pathlib import Path
from urllib.parse import quote_plus 

base_dir = Path(__file__).resolve().parent
src_dir = base_dir/"src"

db_config = {
    "user": "sa",
    "password":quote_plus("Suman@2026!SQL"),
    "server":"localhost",
    "database":"marketingdb",
    "driver":"ODBC Driver 18 for SQL Server"
}
connection_string = (
    f"mssql+pyodbc://{db_config['user']}:{db_config['password']}"
    f"@{db_config['server']}/{db_config['database']}"
    f"?driver={db_config['driver'].replace(' ', '+')}"
    "&Encrypt=no"

)

# twitter request get url

twitter_url =  url = "https://mastodon.social/api/v1/timelines/tag/chess?limit=40"


# aws s3
S3_BUCKET = "etl-suman-files"
S3_INCOMING_PREFIX = ""
S3_ARCHIVE_PREFIX = "archive/"
S3_FAILED_PREFIX = "failed/"
AWS_REGION = "us-east-2"


CSV_PATH = base_dir/"attendance.csv"


# gmail
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
import os

SCOPES = ["https://www.googleapis.com/auth/gmail.readonly"]

client_secret_path = base_dir / "client_secret.json"  
TOKEN_PATH = base_dir / "token.json"  

def get_gmail_service():
    creds = None

    # 1) Load existing token
    if os.path.exists(TOKEN_PATH):
        creds = Credentials.from_authorized_user_file(TOKEN_PATH, SCOPES)

    # 2) If token missing/invalid, do OAuth login
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                str(client_secret_path), SCOPES
            )
            creds = flow.run_local_server(port=0)

        # 3) Save token for next run
        with open(TOKEN_PATH, "w") as f:
            f.write(creds.to_json())

    # 4) Build Gmail API service
    service = build("gmail", "v1", credentials=creds)
    return service



# mongo

mongo_config = {
    "uri": "mongodb://localhost:27017",
    "database": "local",
    "collection": "projects"
}

