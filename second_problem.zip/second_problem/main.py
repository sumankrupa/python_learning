from main_config import connection_string, twitter_url,S3_BUCKET,AWS_REGION,CSV_PATH,get_gmail_service,mongo_config
from sqlalchemy import create_engine 
from src.extract import extract_data
from src.transform import transform_data
from src.load import load_data
from sqlalchemy import create_engine

def main():
    engine = create_engine(connection_string)
    

    mails = extract_data()  
    df = transform_data(mails)
    load_data(engine , df)
    
    


if __name__ == "__main__":
    main()
