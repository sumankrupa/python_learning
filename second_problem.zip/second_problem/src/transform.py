import pandas as pd

def transform_data(mails):
    df = pd.DataFrame(mails)
    print('transform done')
    return df