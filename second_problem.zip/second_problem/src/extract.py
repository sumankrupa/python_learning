from main_config import S3_BUCKET,CSV_PATH,get_gmail_service

import base64
import pandas as pd
from io import BytesIO



def get_header(headers, name):
    name = name.lower()
    for h in headers:
        if h.get('name', '').lower() == name:
            return h.get('value', '')
    return ''


def get_body(payload):
    data = payload.get('body', {}).get('data')
    if not data and payload.get('parts'):
        data = payload['parts'][0].get('body', {}).get('data')
    return base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore') if data else ''



def get_attachments(payload):

    names = []

    for part in payload.get('parts', []):
        if part.get('filename'):
            names.append(part['filename'])

    return names
    
def extract_data():
    service = get_gmail_service()
    resp = service.users().messages().list(
        userId='me',
        q='in:inbox',
        maxResults=1
    ).execute()

    msgs = resp.get('messages', []) or []
    

    records = []
    for i in msgs:
        # get full message for each id
        msg = service.users().messages().get(
            userId='me',
            id=i['id'],
            format='full'
        ).execute()
        payload = msg.get('payload', {}) or {}
        headers = payload.get('headers',[]) or []
 
        records.append({
                'Sender': get_header(headers, 'From'),
                'Receiver': get_header(headers, 'To'),
                'CC': get_header(headers, 'Cc'),
                'Subject': get_header(headers, 'Subject'),
                'Body': get_body(payload),
                'Attachments': ', '.join(get_attachments(payload)),
            })
    print('extract done')
    return records
