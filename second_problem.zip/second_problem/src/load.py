import boto3
from main_config import connection_string, twitter_url,S3_BUCKET,AWS_REGION,CSV_PATH,get_gmail_service,mongo_config
import uuid
def upload_to_s3(bucket, filename, file_bytes):

    s3 = boto3.client('s3')
    key = f'gmail_attachments/{uuid.uuid4()}_{filename}'

    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=file_bytes
    )

    return f's3://{bucket}/{key}'

def load_data(engine , df):
    df['attachment_link1'] = ''
    df['attachment_link2'] = ''
    for idx, row in df.iterrows():

        attachments = row.get('attachments', [])

        if len(attachments) > 0:
            link1 = upload_to_s3(S3_BUCKET,
                                 attachments[0]['filename'],
                                 attachments[0]['bytes'])
            df.at[idx, 'attachment_link1'] = link1

        if len(attachments) > 1:
            link2 = upload_to_s3(S3_BUCKET,
                                 attachments[1]['filename'],
                                 attachments[1]['bytes'])
            df.at[idx, 'attachment_link2'] = link2

    df.to_sql(
        'gmail_tracking',
        con = engine, 
        if_exists='append', 
        index=False)
   
    print('loading done')
    return