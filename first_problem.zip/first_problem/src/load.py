


def load_data(engine , df):
    df.to_sql(
        name = 'EmployeeAttendance',
        con = engine,
        if_exists = 'replace',
        index = False

    )
    print('loading done')
    return