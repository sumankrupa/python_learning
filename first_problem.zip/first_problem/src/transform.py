import pandas as pd

def transform_data( employee_df,attendance_df ):
    # teim leading zereos
    employee_df['emp_id'] = (employee_df['emp_id'].astype(str).
        str.strip().
        str.lstrip('0')
        )
    attendance_df['emp_id'] = (attendance_df['emp_id'].astype(str).
                               str.strip().
                               str.lstrip('0'))
    if 'date' in employee_df.columns:
        employee_df['date'] = pd.to_datetime(employee_df['date'], errors='coerce')
    if 'date' in attendance_df.columns:
        attendance_df['date'] = pd.to_datetime(attendance_df['date'], errors='coerce')
    
    employee_df = employee_df.drop_duplicates(subset='emp_id',keep='first')


    employee_df['dept'] = employee_df['dept'].fillna('Unknown')
    
 
    attendance_df['hours_worked'] = attendance_df['hours_worked'].astype(float)
    avg_value= attendance_df['hours_worked'].mean()
    attendance_df['hours_worked'] = attendance_df['hours_worked'].fillna(avg_value)

    attendance_df = attendance_df[
        (attendance_df['hours_worked'] >= 0) & (attendance_df['hours_worked'] <= 24)
    ]
    employee_df['hire_date'] = pd.to_datetime(employee_df['hire_date'], errors='coerce')

    employee_df['tenure_years'] = (
    pd.Timestamp.now().year - employee_df['hire_date'].dt.year
    )
    employee_df['tenure_category'] = pd.cut(
    employee_df['tenure_years'],
    bins=[0, 1, 5, float('inf')],
    labels=['New', 'Mid', 'Senior'],
    right=False
    )
    
    merged_df = pd.merge(
    employee_df, 
    attendance_df, 
    on='emp_id', 
    how='inner'
    )
    if 'termination_date' in merged_df.columns:
        merged_df['termination_date'] = pd.to_datetime(merged_df['termination_date'], errors='coerce')

    
        merged_df = merged_df[
            merged_df['termination_date'].isna() |
            (merged_df['termination_date'] > pd.Timestamp.now())
        ]

    leave_days_df = (
        merged_df[merged_df['leave_type'].notna()]  # only leave rows
        .groupby('emp_id')['leave_type']
        .count()
        .reset_index(name='leave_days')
    )
    hours_df = (
        merged_df
        .groupby('emp_id')['hours_worked']
        .agg(
            total_hours='sum',
            avg_hours_worked='mean'
        )
        .reset_index()
    )
    merged_df['leave_days'] = (
        merged_df.groupby('emp_id')['leave_type']
        .transform('count')
        )
   
    merged_df['total_hours'] = (
        merged_df.groupby('emp_id')['hours_worked']
        .transform('sum')
    )

    merged_df['avg_hours_worked'] = (
        merged_df.groupby('emp_id')['hours_worked']
        .transform('mean')
    )

    merged_df['dept_avg_hours_worked'] = (
        merged_df.groupby('dept')['hours_worked'].transform('mean')
    )

   
    merged_df['dept_total_leave_days'] = (
        merged_df.groupby('dept')['leave_days'] .transform('sum')
    )

    merged_df['dept_headcount'] = (
        merged_df.groupby('dept')['emp_id'].transform('nunique')
    )
    print('transform done')
    return merged_df