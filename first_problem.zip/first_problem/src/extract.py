from main_config import S3_BUCKET,CSV_PATH

import boto3

import pandas as pd
from io import BytesIO



def extract_data():
    s3 = boto3.client("s3")
    key = "employees.parquet" 
    obj = s3.get_object(Bucket=S3_BUCKET, Key=key)
    data = obj["Body"].read()
    employee_df = pd.read_parquet(BytesIO(data))
    
    attendance_df = pd.read_csv(CSV_PATH)
    print('extract done')
    return employee_df,attendance_df