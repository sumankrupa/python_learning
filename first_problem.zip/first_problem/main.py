from main_config import connection_string, twitter_url,S3_BUCKET,AWS_REGION,CSV_PATH,get_gmail_service,mongo_config
from sqlalchemy import create_engine 
from src.extract import extract_data
from src.transform import transform_data
from src.load import load_data
import requests
import boto3
import csv
from sqlalchemy import create_engine
from pymongo import MongoClient
import json
import pandas as pd
from io import BytesIO

def main():
    engine = create_engine(connection_string)
   

    employee_df,attendance_df = extract_data()  
    df = transform_data( employee_df,attendance_df )
    load_data(engine , df)
    
    


if __name__ == "__main__":
    main()
